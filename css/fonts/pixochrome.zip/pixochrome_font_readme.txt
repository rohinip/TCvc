Pixochrome

Free font created by german designer Britta Hackenberger, 
www.pixochrome.de, 2007

As I'm not a professional font designer this font is free for any kind of use except commercial redistributing or reselling. You are allowed to redistribute it on any free font website, but please make sure to include this readme file.

Anyway if you do use the font for some serious work I'd be very happy if you'd send me a link, voucher copy or pdf of your print layout. I'm just curious what this font is useful for.

Thanks and have fun!

Britta
britta (at) pixochrome.de



